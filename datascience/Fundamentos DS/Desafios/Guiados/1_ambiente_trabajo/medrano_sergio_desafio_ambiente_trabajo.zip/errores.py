# print('Estaba la pájara pinta sentada en el verde limón)
# Falta cerrar el texto con la comilla
print('Estaba la pájara pinta sentada en el verde limón')

#print('Mi nombre es' name 'y tengo' edad, 'años')
#se deben asignar  las variables dentro de {} y toda la cadena debe ir entre unas solas comillas simples, además se debe anteponer una f a la cadena de texto
name = 'Sergio'
edad = 29
print(f'Mi nombre es {name} y tengo {edad} años')

#Esto no presenta un error, solo se debe mencionar que esto debe ir al inicio de un archivo como buena practica
import pandas as pd
import numpy as np

# "Ornitorrinco" + 45
# no se puede concatenar un string con un int, para corregirlo se cambia el int a string
print("Ornitorrinco" + "45")